package com.training.services;

public class RetailService {

}
