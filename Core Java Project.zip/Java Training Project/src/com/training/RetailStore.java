package com.training;

public interface RetailStore {

	public double calculateSales();

}
