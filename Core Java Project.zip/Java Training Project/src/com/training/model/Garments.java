package com.training.model;
import com.training.RetailStore;

public class Garments implements RetailStore {
	
	private String iteCode;
	private String itemName ;
	private double unitPrice;
	private int size;
	private String material;
	private int quantity;
	
	
	public Garments() {
		super();
	}


	public Garments(String iteCode, String itemName, double unitPrice, int size, String material, int quantity) {
		super();
		this.iteCode = iteCode;
		this.itemName = itemName;
		this.unitPrice = unitPrice;
		this.size = size;
		this.material = material;
		this.quantity = quantity;
	}


	public String getIteCode() {
		return iteCode;
	}


	public void setIteCode(String iteCode) {
		this.iteCode = iteCode;
	}


	public String getItemName() {
		return itemName;
	}


	public void setItemName(String itemName) {
		this.itemName = itemName;
	}


	public double getUnitPrice() {
		return unitPrice;
	}


	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}


	public int getSize() {
		return size;
	}


	public void setSize(int size) {
		this.size = size;
	}


	public String getMaterial() {
		return material;
	}


	public void setMaterial(String material) {
		this.material = material;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	@Override
	public double calculateSales() {
		return this.unitPrice*this.quantity;
	}
	
	

}
