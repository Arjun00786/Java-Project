package com.training.model;

import com.training.RetailStore;

public class Electronics implements RetailStore {
	
	private String iteCode;
	private String itemName ;
	private double unitPrice;
	private int size;
	private double warranty;
	private int wattage;
	private int quantity;
	
	public Electronics() {
		super();
	}

	public Electronics(String iteCode, String itemName, double unitPrice, int size, double warranty, int wattage,
			int quantity) {
		super();
		this.iteCode = iteCode;
		this.itemName = itemName;
		this.unitPrice = unitPrice;
		this.size = size;
		this.warranty = warranty;
		this.wattage = wattage;
		this.quantity = quantity;
	}

	public String getIteCode() {
		return iteCode;
	}

	public void setIteCode(String iteCode) {
		this.iteCode = iteCode;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public double getWarranty() {
		return warranty;
	}

	public void setWarranty(double warranty) {
		this.warranty = warranty;
	}

	public int getWattage() {
		return wattage;
	}

	public void setWattage(int wattage) {
		this.wattage = wattage;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public double calculateSales() {
		
		return this.unitPrice*this.quantity;
	}
	
	

}
