package com.training.model;
import com.training.RetailStore;

public class Edible implements RetailStore {
	
	private String iteCode;
	private String itemName ;
	private double unitPrice;
	private String manufactureDate;
	private String expiryDate;
	private String foodType;
	private int quantity;
	
	public Edible() {
		super();
	}

	public Edible(String iteCode, String itemName, double unitPrice, String manufactureDate, String expiryDate,
			String foodType, int quantity) {
		super();
		this.iteCode = iteCode;
		this.itemName = itemName;
		this.unitPrice = unitPrice;
		this.manufactureDate = manufactureDate;
		this.expiryDate = expiryDate;
		this.foodType = foodType;
		this.quantity = quantity;
	}


	public String getIteCode() {
		return iteCode;
	}

	public void setIteCode(String iteCode) {
		this.iteCode = iteCode;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getManufactureDate() {
		return manufactureDate;
	}

	public void setManufactureDate(String manufactureDate) {
		this.manufactureDate = manufactureDate;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getFoodType() {
		return foodType;
	}

	public void setFoodType(String foodType) {
		this.foodType = foodType;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public double calculateSales() {
		
		return this.unitPrice*this.quantity;
	}
	
	
	
	

}
